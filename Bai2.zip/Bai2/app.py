from tkinter import Tk, Label, Entry, Button, messagebox, ttk
import sqlite3

# Đăng nhập
def login():
    username = entry_username.get()
    password = entry_password.get()
    conn = sqlite3.connect("student_management.db")
    cursor = conn.cursor()

    # Kiểm tra tài khoản
    cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
    user = cursor.fetchone()
    conn.close()

    if user:
        main_menu()
    else:
        messagebox.showerror("Lỗi", "Sai tên đăng nhập hoặc mật khẩu!")

# Xem danh sách sinh viên
def view_students():
    conn = sqlite3.connect("student_management.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students")
    rows = cursor.fetchall()
    conn.close()

    for row in tree.get_children():
        tree.delete(row)

    for row in rows:
        tree.insert("", "end", values=row)

# Thêm sinh viên mới
def add_student():
    mssv = entry_mssv.get()
    name = entry_name.get()

    if mssv and name:
        conn = sqlite3.connect("student_management.db")
        cursor = conn.cursor()
        cursor.execute("INSERT INTO students (mssv, name) VALUES (?, ?)", (mssv, name))
        conn.commit()
        conn.close()
        view_students()
        entry_mssv.delete(0, "end")
        entry_name.delete(0, "end")
        messagebox.showinfo("Thành công", "Thêm sinh viên mới thành công!")
    else:
        messagebox.showerror("Lỗi", "Vui lòng nhập đầy đủ thông tin!")

# Menu chính
def main_menu():
    login_window.destroy()
    global main_window, entry_mssv, entry_name, tree
    main_window = Tk()
    main_window.title("Quản lý sinh viên")

    Label(main_window, text="MSSV").grid(row=0, column=0, padx=10, pady=10)
    entry_mssv = Entry(main_window)
    entry_mssv.grid(row=0, column=1, padx=10, pady=10)

    Label(main_window, text="Tên").grid(row=1, column=0, padx=10, pady=10)
    entry_name = Entry(main_window)
    entry_name.grid(row=1, column=1, padx=10, pady=10)

    Button(main_window, text="Thêm", command=add_student).grid(row=2, column=0, columnspan=2, pady=10)

    tree = ttk.Treeview(main_window, columns=("id", "mssv", "name"), show="headings")
    tree.heading("id", text="ID")
    tree.heading("mssv", text="MSSV")
    tree.heading("name", text="Tên")
    tree.grid(row=3, column=0, columnspan=2, padx=10, pady=10)

    Button(main_window, text="Xem danh sách", command=view_students).grid(row=4, column=0, columnspan=2, pady=10)

    main_window.mainloop()

# Cửa sổ đăng nhập
login_window = Tk()
login_window.title("Đăng nhập")

Label(login_window, text="Tên đăng nhập").grid(row=0, column=0, padx=10, pady=10)
entry_username = Entry(login_window)
entry_username.grid(row=0, column=1, padx=10, pady=10)

Label(login_window, text="Mật khẩu").grid(row=1, column=0, padx=10, pady=10)
entry_password = Entry(login_window, show="*")
entry_password.grid(row=1, column=1, padx=10, pady=10)

Button(login_window, text="Đăng nhập", command=login).grid(row=2, column=0, columnspan=2, pady=10)

login_window.mainloop()

import tkinter as tk
from tkinter import messagebox

# Hàm xử lý tính toán
def calculate():
    try:
        num1 = float(entry1.get())
        num2 = float(entry2.get())
        operator = operator_var.get()

        if operator == "+":
            result = num1 + num2
        elif operator == "-":
            result = num1 - num2
        elif operator == "*":
            result = num1 * num2
        elif operator == "/":
            if num2 == 0:
                raise ZeroDivisionError
            result = num1 / num2
        else:
            raise ValueError("Phép tính không hợp lệ!")
        
        print(f"Result: {result}")
        result_label.config(text=f"Kết quả: {result}")
    except ValueError:
        messagebox.showerror("Lỗi", "Vui lòng nhập số hợp lệ!")
    except ZeroDivisionError:
        messagebox.showerror("Lỗi", "Không thể chia cho 0!")

# Hàm để thoát ứng dụng
def exit_app():
    window.destroy()

# Tạo giao diện chính
window = tk.Tk()
window.title("Máy tính đơn giản")
window.geometry("300x300")
window.resizable(False, False)

# Nhãn và ô nhập số thứ nhất
tk.Label(window, text="Số thứ nhất:").pack(pady=5)
entry1 = tk.Entry(window)
entry1.pack(pady=5)

# Nhãn và ô nhập số thứ hai
tk.Label(window, text="Số thứ hai:").pack(pady=5)
entry2 = tk.Entry(window)
entry2.pack(pady=5)

# Tùy chọn phép tính
tk.Label(window, text="Chọn phép tính:").pack(pady=5)
operator_var = tk.StringVar(value="+")
operators = ["+", "-", "*", "/"]
for op in operators:
    tk.Radiobutton(window, text=op, variable=operator_var, value=op).pack()

# Nút tính toán
calc_button = tk.Button(window, text="Tính toán", command=calculate, bg="green", fg="white")
calc_button.pack(pady=10)

# Nhãn hiển thị kết quả
result_label = tk.Label(window, text="Kết quả: ", font=("Arial", 12))
result_label.pack(pady=10)

# Nút thoát
exit_button = tk.Button(window, text="Thoát", command=exit_app, bg="red", fg="white")
exit_button.pack(pady=10)

# Chạy ứng dụng
window.mainloop()

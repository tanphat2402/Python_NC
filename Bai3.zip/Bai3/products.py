products = [
    # New
    {"id": 1, "name": "NIKE C1TY", "price": "3.999.000 VNĐ", "image": "images/new8.png", "category": "Product"},
    {"id": 2, "name": "AIR JORDAN 1", "price": "152,000 vnđ", "image": "images/new7.png", "category": "Product"},
    {"id": 3, "name": "KILLSHOT", "price": "249,000", "image": "images/new6.png", "category": "Product"},
]

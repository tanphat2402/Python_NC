products1 = [
    # New
    {"id": 1, "name": "NIKE C1TY", "price": "2,999,000", "image": "images/new1.png", "category": "new", "type": "KIID0029-01", "color": "Black"},
    {"id": 2, "name": "Air JORDAN 1", "price": "3,552,000", "image": "images/new2.png", "category": "new", "type": "BG06", "color": ""},
    {"id": 3, "name": "Air JORDAN 1 LOW SE", "price": "3,349,000", "image": "images/new3.png", "category": "new", "type": "NOID0042-01", "color": "White/Black"},
    {"id": 4, "name": "Air JORDAN 1 Elevate Low", "price": "3,900,000", "image": "images/new4.png", "category": "new", "type": "Men's Long-Sleeve T-Shirt", "color": "Black"},
    {"id": 5, "name": "Air JORDAN 1 MID SE", "price": "4,500,000", "image": "images/new5.png", "category": "new", "type": "Nike Sportswear", "color": "Black"},

    {"id": 6, "name": "NIKE C1TY 1 Low", "price": "2,999,000", "image": "images/new9.png", "category": "new", "type": "KIID0029-01", "color": "Black"},
    {"id": 7, "name": "Air JORDAN 1 MIDNIGHT", "price": "3,552,000 vnđ", "image": "images/new10.png", "category": "new", "type": "BG06", "color": ""},
    {"id": 8, "name": "Air JORDAN 2 LOW SE", "price": "3,349,000", "image": "images/new11.png", "category": "new", "type": "NOID0042-01", "color": "White/Black"},
    {"id": 9, "name": "Air JORDAN 3 Elevate Low", "price": "3,900,000", "image": "images/new12.png", "category": "new", "type": "Men's Long-Sleeve T-Shirt", "color": "Black"},
    {"id": 10, "name": "Air JORDAN 4 MID LOW SE", "price": "4,500,000", "image": "images/new7.png", "category": "new", "type": "Nike Sportswear", "color": "Black"},

]
